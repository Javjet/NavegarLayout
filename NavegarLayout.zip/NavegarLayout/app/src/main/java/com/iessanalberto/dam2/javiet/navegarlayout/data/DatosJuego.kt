package com.iessanalberto.dam2.javiet.navegarlayout.data

import com.iessanalberto.dam2.javiet.navegarlayout.CientificasLista

val Cientificas_Max:Int = CientificasLista.size
var Cientificas_Act:Int = CientificasLista.size
const val SCORE_INCREASE = 20