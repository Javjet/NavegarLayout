package com.iessanalberto.dam2.javiet.navegarlayout.data

//data class Cientificas(val nombre : String, val Pistas : Array<String>, val ImageId : Int, val Info: String)
 data class Cientificas(val nombre : String, val Pistas : Array<String>, val ImageId : Int) {


}